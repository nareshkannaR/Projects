import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function About() {
  const navigate = useNavigate();

  return (
    <div className="mt-8 bg-gray-800 rounded-lg p-8 shadow-lg">
      <button
        onClick={() => navigate(-1)}
        className="mb-6 flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
      >
        <ArrowLeft size={20} />
        Back
      </button>

      <h2 className="text-3xl font-bold mb-6 bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
        About Img removerzz
      </h2>
      <div className="space-y-6 text-gray-300">
        <p className="text-lg">
          Img removerzz is a cutting-edge AI-powered background removal tool that helps you create professional-looking images in seconds.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-900/50 p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-3 text-white">Our Technology</h3>
            <p>Using advanced machine learning algorithms, we can accurately detect and remove backgrounds from any image while preserving fine details.</p>
          </div>
          <div className="bg-gray-900/50 p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-3 text-white">Why Choose Us</h3>
            <ul className="list-disc list-inside space-y-2">
              <li>Fast and accurate processing</li>
              <li>User-friendly interface</li>
              <li>High-quality output</li>
              <li>Free to use</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}