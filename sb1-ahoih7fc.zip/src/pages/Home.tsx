import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Download, Image as ImageIcon, Wand2 } from 'lucide-react';
import { removeBackground } from '../services/backgroundRemoval';

const sampleImages = [
  {
    url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=500',
    title: 'Portrait'
  },
  {
    url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=500',
    title: 'Product'
  },
  {
    url: 'https://images.unsplash.com/photo-1533450718592-29d45635f0a9?auto=format&fit=crop&w=500',
    title: 'Nature'
  }
];

export default function Home() {
  const [image, setImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processImage = async (file: File) => {
    try {
      setIsProcessing(true);
      setError(null);
      const reader = new FileReader();
      reader.onload = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);

      const processedImageUrl = await removeBackground(file);
      setProcessedImage(processedImageUrl);
    } catch (err) {
      setError('Failed to process image. Please try again.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      processImage(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
    multiple: false
  });

  const handleDownload = async () => {
    if (processedImage) {
      const link = document.createElement('a');
      link.href = processedImage;
      link.download = 'processed-image.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const loadSampleImage = async (url: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const file = new File([blob], 'sample-image.jpg', { type: 'image/jpeg' });
      processImage(file);
    } catch (err) {
      setError('Failed to load sample image. Please try again.');
    }
  };

  return (
    <>
      {/* Hero Section */}
      {!image && !processedImage && (
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Remove Image Backgrounds</h2>
          <p className="text-gray-400 text-lg mb-8">
            100% automatic and free - remove backgrounds from images in seconds
          </p>
        </div>
      )}

      {/* Upload Area */}
      {!image && !processedImage && (
        <>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
              border-gray-700 hover:border-gray-500
              ${isDragActive ? 'border-blue-500 bg-blue-500/10' : ''}`}
          >
            <input {...getInputProps()} />
            <ImageIcon className="mx-auto mb-4 text-blue-500" size={64} />
            <p className="text-xl mb-2">Drag & drop your image here</p>
            <p className="text-gray-400 mb-6">or</p>
            <button className="px-8 py-3 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors
              flex items-center gap-2 mx-auto text-lg">
              <Upload size={24} />
              Choose File
            </button>
          </div>

          {/* Sample Images */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold mb-6 text-center">Try with Sample Images</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {sampleImages.map((sample, index) => (
                <div
                  key={index}
                  onClick={() => loadSampleImage(sample.url)}
                  className="bg-gray-800 rounded-lg overflow-hidden cursor-pointer transform hover:scale-105 transition-transform"
                >
                  <img 
                    src={sample.url} 
                    alt={sample.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <p className="text-center font-medium">{sample.title}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Error Message */}
      {error && (
        <div className="mt-4 p-4 bg-red-900/50 text-red-200 rounded-lg border border-red-700">
          {error}
        </div>
      )}

      {/* Processing State */}
      {isProcessing && image && (
        <div className="mt-8">
          <div className="relative w-full h-[600px] overflow-hidden rounded-lg bg-gray-800">
            <img 
              src={image} 
              alt="Processing" 
              className="absolute inset-0 w-full h-full object-contain"
            />
            <div className="absolute inset-0 bg-black bg-opacity-75 flex flex-col items-center justify-center backdrop-blur-sm">
              <Wand2 size={64} className="text-blue-500 animate-bounce" />
              <p className="text-2xl mt-4 mb-8">Removing Background...</p>
              <div className="w-64 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 animate-progress rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Result Area */}
      {image && processedImage && !isProcessing && (
        <div className="mt-8 grid grid-cols-2 gap-8">
          {/* Original Image */}
          <div className="bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-medium mb-4 text-center">Original Image</h3>
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-900">
              <img 
                src={image} 
                alt="Original" 
                className="w-full h-full object-contain"
              />
            </div>
          </div>

          {/* Processed Image */}
          <div className="bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-medium mb-4 text-center">Background Removed</h3>
            <div className="aspect-square rounded-lg overflow-hidden bg-[url('/checkered-pattern.png')]">
              <img
                src={processedImage}
                alt="Processed"
                className="w-full h-full object-contain"
              />
            </div>
          </div>

          {/* Download Button */}
          <div className="col-span-2 text-center mt-4">
            <button 
              onClick={handleDownload}
              className="px-8 py-3 rounded-full bg-green-500 text-white hover:bg-green-600 transition-colors
              flex items-center gap-2 mx-auto text-lg">
              <Download size={24} />
              Download Result
            </button>
          </div>
        </div>
      )}

      {/* Features Section */}
      {!image && !processedImage && (
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
              <Wand2 className="text-blue-500" size={24} />
            </div>
            <h3 className="text-lg font-semibold mb-2">AI-Powered</h3>
            <p className="text-gray-400">Advanced AI technology for precise background removal</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
              <Download className="text-purple-500" size={24} />
            </div>
            <h3 className="text-lg font-semibold mb-2">Free Download</h3>
            <p className="text-gray-400">Download your processed images instantly</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
              <ImageIcon className="text-green-500" size={24} />
            </div>
            <h3 className="text-lg font-semibold mb-2">High Quality</h3>
            <p className="text-gray-400">Maintain original image quality after processing</p>
          </div>
        </div>
      )}
    </>
  );
}