import { API_KEY } from '../config';

const isDevelopment = import.meta.env.DEV;

export async function removeBackground(file: File): Promise<string> {
  try {
    if (isDevelopment && API_KEY === 'y5wCn5VW8TJvmMQC7WDjz6H7e') {
      // Development fallback - simulate API call with a delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      // Return a sample transparent background image for testing
      return 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=500';
    }

    const formData = new FormData();
    formData.append('image_file', file);

    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': API_KEY,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const blob = await response.blob();
    return URL.createObjectURL(blob);
  } catch (error) {
    console.error('Error removing background:', error);
    throw error;
  }
}