import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Eraser, Home, Info, Mail, Menu, X } from 'lucide-react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-3">
              <Eraser size={32} className="text-blue-500" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                Img removerzz
              </h1>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <Link
                to="/"
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
                  ${isActive('/') ? 'bg-blue-500 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                <Home size={20} />
                Home
              </Link>
              <Link
                to="/about"
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
                  ${isActive('/about') ? 'bg-blue-500 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                <Info size={20} />
                About
              </Link>
              <Link
                to="/contact"
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
                  ${isActive('/contact') ? 'bg-blue-500 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                <Mail size={20} />
                Contact
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-gray-800"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="md:hidden border-t border-gray-800 bg-gray-900">
            <div className="container mx-auto px-4 py-4 space-y-2">
              <Link
                to="/"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`w-full flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
                  ${isActive('/') ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
              >
                <Home size={20} />
                Home
              </Link>
              <Link
                to="/about"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`w-full flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
                  ${isActive('/about') ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
              >
                <Info size={20} />
                About
              </Link>
              <Link
                to="/contact"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`w-full flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
                  ${isActive('/contact') ? 'bg-blue-500 text-white' : 'text-gray-400'}`}
              >
                <Mail size={20} />
                Contact
              </Link>
            </div>
          </nav>
        )}
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {children}
      </div>
    </div>
  );
}