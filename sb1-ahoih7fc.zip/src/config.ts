// Replace this with your actual API key when ready
export const API_KEY = 'y5wCn5VW8TJvmMQC7WDjz6H7';